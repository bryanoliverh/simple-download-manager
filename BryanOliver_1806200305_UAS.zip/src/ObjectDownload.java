public class ObjectDownload {
    String URL = "";
    int filesize = 0;
    int awl = 0;
    int[] arrayint = new int[3];
}